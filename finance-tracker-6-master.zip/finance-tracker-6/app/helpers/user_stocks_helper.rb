module UserStocksHelper
end
